#ifndef COOKAREATYPE_H
#define COOKAREATYPE_H


class CookArea {
public:
    enum class Type {
        Stove,
        CuttingBoard,
        PrepSink
    };
};

#endif // COOKAREATYPE_H
